#Setup CalCalc

import distutils
from distutils.core import setup
setup(name='CalCalc',
      version='1.0',
      author='Francine Foo',
      author_email='francinefoo@berkeley.edu',
      py_modules=['CalCalc'])