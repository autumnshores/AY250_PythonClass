# Calculate module

import argparse
parser = argparse.ArgumentParser(description='Calculate Stuff')
parser.add_argument('-s', action='store', dest='string',
                    help='Store a string (equation to calculate)')

results = parser.parse_args()


def Calculate(n):
    try:
        answer = eval(n)
        print answer
    except:
        print 'Cannot calculate '+str(n)+' using eval(). Getting Wolfram Alpha to help...'
        import urllib2
        #import urllib
        response = urllib2.urlopen('http://api.wolframalpha.com/v2/query?input='+str(n.replace(' ','+'))+'&appid=UAGAWR-3X6Y8W777Q')
        print response.read() #Q2a not complete yet

if __name__ == "__main__":
    import sys
    Calculate(str(sys.argv[2]))