## How to install CalCalc.py

1) In the CalCalc-1.0 directory, unpack CalCalc-1.0.tar.gz
2) run in the command line: python setup.py install

## How to run the 5 tests in CalCalc.py
type the following in the command line:
$nosetests